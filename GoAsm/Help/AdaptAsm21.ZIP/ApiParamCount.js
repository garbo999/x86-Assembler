var possWhite = '\\s*', realWhite = '\\s+', realWord = '\\w+', leftParen = '\\(', rightParen = '\\)',
		possAnyStrThrifty = '(?:.|\\n)*?',
		apiCore = 'APIENTRY|[A-Z]+API(?:V)?',
		apiSuffixOpt = '(?:_\\x28'+ realWord +'(?:\\s+\\x2a)?\\x29)?',
		cDeclOpt = '(?:'+ realWhite + realWord  + realWhite +'__cdecl)?',
		ifDefOpt = '(?:'+ realWhite +'#if'+ possAnyStrThrifty + realWhite +'#endif)?',
		regExMainString =	possWhite +
											'(?:' + apiCore + apiSuffixOpt + cDeclOpt + ifDefOpt + ')'+ realWhite +
											'('+ realWord +')'+ possWhite +
											leftParen +'('+ possAnyStrThrifty +')'+ rightParen + possWhite +';', regExMain = / /g,
		regExForParen = /\x28(?:.|\n)+?\x29/g, regExForTrailingEllipsis = /[.]{3,3}$/, regExForVoid = /^\s*(?:void)?\s*$/i,
		regExForLineComment = /\x2f\x2f.*?\n/g, regExForExtendedComment = /\x2f\x2a(?:.|\n)*?\x2a\x2f/g,
		regExForAnnotation = /__(?:[be]count\x28\w+\x29)/g, regExForInline = /__inline\s+\w+\s+NTAPI/g;
regExMain.compile(regExMainString, 'g');
String.prototype.purgeParen = function(){return this.replace(regExForParen, ' ')};
function parseApiDeclaration(myString){
	var myArray, s, myCount = 0;
	if(myArray = regExMain.exec(myString)){
		if(regExForTrailingEllipsis.test(myArray[2])){return [myArray[1], 'v']};
		s = myArray[2].purgeParen().split(',');
		if(s.length > 1){myCount = s.length}
		else{myCount = (regExForVoid.test(myArray[2])) ? 0 : 1};
		return [myArray[1], myCount];
	};
	return null;
};
var scriptArg = WScript.Arguments;
if(!scriptArg.length){WScript.Echo('Script needs a filename argument'); WScript.Quit(3)};
var fso = new ActiveXObject('Scripting.FileSystemObject');
var src = fso.OpenTextFile(scriptArg(0), 1, false, false); if(!src){WScript.Echo('File not found'); WScript.Quit(2)};
var myString = src.ReadAll(); src.Close();
if(!myString){WScript.Echo('File contents unavailable'); WScript.Quit(1)};
myString = myString.replace(regExForExtendedComment, '').replace(regExForLineComment, '\n');
myString = myString.replace(regExForAnnotation, '').replace(regExForInline, '');
var outFile = fso.CreateTextFile(scriptArg(0) +'.txt'), t;
while(t = parseApiDeclaration(myString)){outFile.Write(t +'\r\n')};
outFile.Close()

/*
var regExMain = /\s*(?:APIENTRY|[A-Z]+API(?:_\(\w+\))?(?:\s+\w+\s+__cdecl)?)\s+(\w+)\s*\(([^\(\)]+)\)\s*;/g,
		regExForNestedParen = /(\([^\)]*?)(\([^\(]*?\))/g;
myString = myString.replace(regExForNestedParen, '$1');
WScript.Echo(regExMain); WScript.Quit();
WScript.Echo(scriptArg(0)); WScript.Quit();
STDAPIV
WINAPIV
VFWAPIV
LWSTDAPIV
STDAPIVCALLTYPE
*/